"""فیلترهای قابل ترکیب با & و | و ~"""
import re

from .types.callback import CallbackQuery


class Filter:
    def __init__(self, func, name=None):
        self.func = func
        self.name = name or getattr(func, "__name__", "filter")

    def __call__(self, update):
        return bool(self.func(update))

    def __and__(self, other):
        return Filter(lambda u: self(u) and other(u), f"({self.name} & {other.name})")

    def __or__(self, other):
        return Filter(lambda u: self(u) or other(u), f"({self.name} | {other.name})")

    def __invert__(self):
        return Filter(lambda u: not self(u), f"~{self.name}")

    def __repr__(self):
        return f"<Filter {self.name}>"


def create(func, name=None):
    """از یک تابع ساده فیلتر می‌سازد."""
    return Filter(func, name)


def _msg(update):
    return update.message if isinstance(update, CallbackQuery) else update


def _text(update):
    m = _msg(update)
    return (getattr(m, "text", None) or getattr(m, "caption", None) or "") if m else ""


def _as_list(value):
    if isinstance(value, (list, tuple, set, frozenset)):
        return list(value)
    return [value]


def command(commands, prefixes="/"):
    cmds = {c.lstrip("/").lower() for c in _as_list(commands)}
    pres = tuple(_as_list(prefixes))

    def check(update):
        text = _text(update)
        if not text:
            return False
        first = text.split(None, 1)[0]
        for p in pres:
            if first.startswith(p):
                name = first[len(p):].split("@", 1)[0].lower()
                if name in cmds:
                    return True
        return False

    return Filter(check, f"command({sorted(cmds)})")


def regex(pattern, flags=0):
    compiled = re.compile(pattern, flags)

    def check(update):
        m = compiled.search(_text(update))
        if m:
            update.match = m
            return True
        return False

    return Filter(check, f"regex({pattern!r})")


def user(user_ids):
    ids = {int(i) for i in _as_list(user_ids)}
    return Filter(
        lambda u: bool(u.from_user) and u.from_user.id in ids, f"user({sorted(ids)})"
    )


def chat(chat_ids):
    ids = {int(i) for i in _as_list(chat_ids)}

    def check(update):
        m = _msg(update)
        return bool(m and m.chat and m.chat.id in ids)

    return Filter(check, f"chat({sorted(ids)})")


def _chat_type(type_name):
    def check(update):
        m = _msg(update)
        return bool(m and m.chat and m.chat.type == type_name)

    return Filter(check, type_name)


private = _chat_type("private")
group = _chat_type("group")
supergroup = _chat_type("supergroup")
channel = _chat_type("channel")
text = Filter(lambda u: bool(getattr(_msg(u), "text", None)), "text")
