"""لایهٔ HTTP بدون وابستگی (فقط کتابخونهٔ استاندارد پایتون)."""
import json
import mimetypes
import os
import urllib.error
import urllib.request
import uuid

from .errors import NetworkError


def _open(req, timeout):
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except (urllib.error.URLError, OSError) as e:
        raise NetworkError(
            f"Network error: {e}. Check your internet and the base_url."
        ) from e


def http_post(url, body, content_type, timeout=60):
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={"Content-Type": content_type, "Accept": "application/json"},
    )
    return _open(req, timeout)


def http_get(url, timeout=60):
    return _open(urllib.request.Request(url, method="GET"), timeout)


def _stringify(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def encode_multipart(fields, files):
    """fields: dict ساده، files: {field: (filename, bytes)} ← (body, content_type)"""
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
            + _stringify(value).encode("utf-8")
            + b"\r\n"
        )
    for name, (filename, content) in files.items():
        ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        safe = os.path.basename(filename).replace('"', "_")
        parts.append(
            (
                f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; '
                f'filename="{safe}"\r\nContent-Type: {ctype}\r\n\r\n'
            ).encode("utf-8")
            + content
            + b"\r\n"
        )
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"
