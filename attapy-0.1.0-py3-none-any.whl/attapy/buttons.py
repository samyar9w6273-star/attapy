"""ساخت دکمه و صفحه‌کلید."""


def _flatten(buttons):
    out = []
    for b in buttons:
        if isinstance(b, (list, tuple)):
            out.extend(_flatten(b))
        elif b is not None:
            out.append(b)
    return out


class Button:
    @staticmethod
    def inline(text, callback_data=None, url=None):
        """دکمهٔ شیشه‌ای (inline)."""
        btn = {"text": text}
        if callback_data is not None:
            btn["callback_data"] = callback_data
        if url is not None:
            btn["url"] = url
        return btn

    @staticmethod
    def keyboard(text, request_contact=False, request_location=False):
        """دکمهٔ صفحه‌کلید معمولی (reply keyboard)."""
        btn = {"text": text}
        if request_contact:
            btn["request_contact"] = True
        if request_location:
            btn["request_location"] = True
        return btn

    @staticmethod
    def row(*buttons):
        """چند دکمه (یا لیستی از دکمه‌ها) را در یک ردیف قرار می‌دهد."""
        return _flatten(buttons)

    @staticmethod
    def inline_markup(rows):
        return {"inline_keyboard": [_flatten(r) if isinstance(r, (list, tuple)) else [r] for r in rows]}

    @staticmethod
    def keyboard_markup(rows, resize_keyboard=True, one_time_keyboard=False,
                        input_field_placeholder=None, selective=None):
        markup = {
            "keyboard": [_flatten(r) if isinstance(r, (list, tuple)) else [r] for r in rows],
            "resize_keyboard": resize_keyboard,
            "one_time_keyboard": one_time_keyboard,
        }
        if input_field_placeholder is not None:
            markup["input_field_placeholder"] = input_field_placeholder
        if selective is not None:
            markup["selective"] = selective
        return markup

    @staticmethod
    def remove_keyboard(selective=None):
        markup = {"remove_keyboard": True}
        if selective is not None:
            markup["selective"] = selective
        return markup

    @staticmethod
    def force_reply(input_field_placeholder=None, selective=None):
        markup = {"force_reply": True}
        if input_field_placeholder is not None:
            markup["input_field_placeholder"] = input_field_placeholder
        if selective is not None:
            markup["selective"] = selective
        return markup

    @staticmethod
    def builder(inline=False):
        """سازندهٔ زنجیره‌ای:
        Button.builder(inline=True).add(Button.inline("A", "a")).new_row().add(...).build()
        """
        return _KeyboardBuilder(inline)


class _KeyboardBuilder:
    def __init__(self, inline=False):
        self.inline = inline
        self._rows = [[]]

    def add(self, *args, **kwargs):
        """دکمه‌ها را به ردیف فعلی اضافه می‌کند. یا خود دکمه، یا text=... و ..."""
        if args:
            self._rows[-1].extend(_flatten(args))
        elif kwargs:
            maker = Button.inline if self.inline else Button.keyboard
            self._rows[-1].append(maker(**kwargs))
        return self

    def row(self, *buttons):
        if self._rows[-1]:
            self._rows.append([])
        self._rows[-1].extend(_flatten(buttons))
        self._rows.append([])
        return self

    def new_row(self):
        if self._rows[-1]:
            self._rows.append([])
        return self

    def build(self, **kwargs):
        rows = [r for r in self._rows if r]
        if self.inline:
            return Button.inline_markup(rows)
        return Button.keyboard_markup(rows, **kwargs)
