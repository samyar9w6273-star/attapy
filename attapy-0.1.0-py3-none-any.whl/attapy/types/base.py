class TLObject:
    """پایهٔ همهٔ آبجکت‌های Bot API. فیلدهای ناشناخته هم با نقطه در دسترس‌اند."""

    def __init__(self, data=None, bot=None):
        self._data = dict(data or {})
        self._bot = bot

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self.__dict__.get("_data", {}).get(name)

    def to_dict(self):
        return self._data

    def __repr__(self):
        return f"<{type(self).__name__} {self._data!r}>"
