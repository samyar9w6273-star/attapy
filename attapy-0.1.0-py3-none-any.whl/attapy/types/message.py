from .base import TLObject
from .chat import Chat
from .user import User


class Message(TLObject):
    def __init__(self, data=None, bot=None):
        super().__init__(data, bot)
        d = self._data
        self.chat = Chat(d["chat"], bot) if isinstance(d.get("chat"), dict) else None
        self.from_user = User(d["from"], bot) if isinstance(d.get("from"), dict) else None
        self.reply_to_message = (
            Message(d["reply_to_message"], bot)
            if isinstance(d.get("reply_to_message"), dict)
            else None
        )
        self.command_args = ""

    @property
    def id(self):
        return self._data.get("message_id")

    @property
    def chat_id(self):
        return self.chat.id if self.chat else None

    # ---- ارسال پاسخ ----
    async def reply(self, text, **kwargs):
        kwargs.setdefault("reply_to_message_id", self.id)
        return await self._bot.send_message(self.chat_id, text, **kwargs)

    async def reply_photo(self, photo, caption=None, **kwargs):
        return await self._bot.send_photo(self.chat_id, photo, caption=caption, **kwargs)

    async def reply_video(self, video, caption=None, **kwargs):
        return await self._bot.send_video(self.chat_id, video, caption=caption, **kwargs)

    async def reply_audio(self, audio, caption=None, **kwargs):
        return await self._bot.send_audio(self.chat_id, audio, caption=caption, **kwargs)

    async def reply_voice(self, voice, caption=None, **kwargs):
        return await self._bot.send_voice(self.chat_id, voice, caption=caption, **kwargs)

    async def reply_document(self, document, caption=None, **kwargs):
        return await self._bot.send_document(self.chat_id, document, caption=caption, **kwargs)

    async def reply_animation(self, animation, caption=None, **kwargs):
        return await self._bot.send_animation(self.chat_id, animation, caption=caption, **kwargs)

    async def reply_sticker(self, sticker, **kwargs):
        return await self._bot.send_sticker(self.chat_id, sticker, **kwargs)

    async def reply_video_note(self, video_note, **kwargs):
        return await self._bot.send_video_note(self.chat_id, video_note, **kwargs)

    async def reply_contact(self, phone_number, first_name, last_name=None, **kwargs):
        return await self._bot.send_contact(
            self.chat_id, phone_number, first_name, last_name=last_name, **kwargs
        )

    async def reply_location(self, latitude, longitude, **kwargs):
        return await self._bot.send_location(self.chat_id, latitude, longitude, **kwargs)

    async def reply_dice(self, emoji=None, **kwargs):
        return await self._bot.send_dice(self.chat_id, emoji=emoji, **kwargs)

    # ---- ویرایش و مدیریت ----
    async def edit_text(self, text, **kwargs):
        return await self._bot.edit_message_text(
            text, chat_id=self.chat_id, message_id=self.id, **kwargs
        )

    async def edit_caption(self, caption, **kwargs):
        return await self._bot.edit_message_caption(
            chat_id=self.chat_id, message_id=self.id, caption=caption, **kwargs
        )

    async def edit_reply_markup(self, reply_markup, **kwargs):
        return await self._bot.edit_message_reply_markup(
            chat_id=self.chat_id, message_id=self.id, reply_markup=reply_markup, **kwargs
        )

    async def delete(self):
        return await self._bot.delete_message(self.chat_id, self.id)

    async def forward(self, to_chat_id, **kwargs):
        return await self._bot.forward_message(to_chat_id, self.chat_id, self.id, **kwargs)

    async def pin(self, **kwargs):
        return await self._bot.pin_chat_message(self.chat_id, self.id, **kwargs)

    async def unpin(self, **kwargs):
        return await self._bot.unpin_chat_message(self.chat_id, self.id, **kwargs)
