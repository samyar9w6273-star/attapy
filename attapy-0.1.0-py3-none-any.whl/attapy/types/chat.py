from .base import TLObject


class Chat(TLObject):
    @property
    def is_private(self):
        return self._data.get("type") == "private"

    @property
    def is_group(self):
        return self._data.get("type") in ("group", "supergroup")
