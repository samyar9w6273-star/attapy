from .base import TLObject
from .message import Message
from .user import User


class CallbackQuery(TLObject):
    def __init__(self, data=None, bot=None):
        super().__init__(data, bot)
        d = self._data
        self.from_user = User(d["from"], bot) if isinstance(d.get("from"), dict) else None
        self.message = Message(d["message"], bot) if isinstance(d.get("message"), dict) else None

    async def answer(self, text=None, show_alert=False, url=None, cache_time=None):
        return await self._bot.answer_callback_query(
            self.id, text=text, show_alert=show_alert, url=url, cache_time=cache_time
        )


class Callback(CallbackQuery):
    """نام دیگر CallbackQuery (سازگاری با aiosroosh)."""
