from .base import TLObject


class User(TLObject):
    @property
    def full_name(self):
        parts = [self._data.get("first_name"), self._data.get("last_name")]
        return " ".join(p for p in parts if p)

    @property
    def mention(self):
        return "@" + self.username if self.username else self.full_name
