"""کلاس اصلی Robot: دریافت آپدیت (long polling)، هندلرها و همهٔ متدهای Bot API."""
import asyncio
import inspect
import json
import logging
import os

from .._http import encode_multipart, http_get, http_post
from ..buttons import _KeyboardBuilder
from ..errors import (
    FloodWait, NetworkError, AttapyError, SoroushPlusAPIError, Unauthorized,
    ValidationError, raise_for_error,
)
from ..events import ErrorHandlerBuilder, HandlerPriority
from ..types import Callback, Message

logger = logging.getLogger("attapy")

# آدرس پایهٔ Bot API سروش‌پلاس؛ الگوی رسمی: https://api.splus.ir/bot<token>/<METHOD_NAME>
# در صورت نیاز با Robot(base_url=...) یا متغیر محیطی ATTAPY_BASE_URL قابل تغییر است.
DEFAULT_BASE_URL = "https://api.splus.ir"


class _Handler:
    def __init__(self, func, filter, commands, priority, order):
        self.func = func
        self.filter = filter
        self.commands = commands
        self.priority = priority
        self.order = order


class _CallbackHandler(_Handler):
    def __init__(self, func, data, filter, priority, order):
        super().__init__(func, filter, None, priority, order)
        self.data = data


def _drop_none(d):
    return {k: v for k, v in d.items() if v is not None}


class Robot:
    def __init__(self, token, base_url=None, parse_mode=None, timeout=60):
        if not token or not isinstance(token, str):
            raise ValidationError("token is required")
        self.token = token
        self.base_url = (
            base_url or os.environ.get("ATTAPY_BASE_URL") or DEFAULT_BASE_URL
        ).rstrip("/")
        self.parse_mode = parse_mode
        self.timeout = timeout
        self.errors = ErrorHandlerBuilder()
        self._handlers = []
        self._callback_handlers = []
        self._order = 0
        self._offset = None
        self._running = False
        self._task = None

    # ------------------------------------------------------------------ پایه
    def _method_url(self, method):
        return f"{self.base_url}/bot{self.token}/{method}"

    def file_url(self, file_path):
        return f"{self.base_url}/file/bot{self.token}/{file_path}"

    async def _ensure_session(self):
        # این کتابخونه نشست دائمی ندارد؛ برای سازگاری با aiosroosh نگه داشته شده.
        return self

    async def start(self):
        return self

    async def close(self):
        """polling را متوقف می‌کند."""
        self.stop()
        if self._task and not self._task.done():
            self._task.cancel()

    async def close_bot(self):
        """متد Bot API با نام close."""
        return await self._request("close")

    async def __aenter__(self):
        return await self.start()

    async def __aexit__(self, *exc):
        await self.close()

    @staticmethod
    def _markup(reply_markup):
        if isinstance(reply_markup, _KeyboardBuilder):
            return reply_markup.build()
        return reply_markup

    async def _request(self, method, params=None, files=None, timeout=None):
        params = _drop_none(params or {})
        if "reply_markup" in params:
            params["reply_markup"] = self._markup(params["reply_markup"])
        url = self._method_url(method)
        if files:
            body, ctype = encode_multipart(params, files)
        else:
            body, ctype = json.dumps(params, ensure_ascii=False).encode("utf-8"), "application/json"
        status, raw = await asyncio.to_thread(http_post, url, body, ctype, timeout or self.timeout)
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except ValueError:
            raise SoroushPlusAPIError(method, f"Invalid response (HTTP {status})", status)
        if isinstance(data, dict) and data.get("ok"):
            return data.get("result")
        raise_for_error(method, data, status)

    async def _send_media(self, api_method, chat_id, field, media, extra=None, **kwargs):
        params = {"chat_id": chat_id}
        params.update(_drop_none(extra or {}))
        params.update(kwargs)
        files = None
        if isinstance(media, (bytes, bytearray)):
            files = {field: (field, bytes(media))}
        elif hasattr(media, "read"):
            name = os.path.basename(getattr(media, "name", field))
            files = {field: (name, media.read())}
        elif isinstance(media, (str, os.PathLike)) and not str(media).startswith(("http://", "https://")) \
                and os.path.isfile(str(media)):
            with open(media, "rb") as f:
                files = {field: (os.path.basename(str(media)), f.read())}
        else:
            params[field] = media
        return await self._request(api_method, params, files)

    def _pm(self, parse_mode):
        return parse_mode if parse_mode is not None else self.parse_mode

    # ------------------------------------------------------------- ثبت هندلر
    def on_message(self, filter=None, commands=None, priority=HandlerPriority.NORMAL):
        """دکوراتور هندلر پیام. filter از attapy.filters، commands مثل ["start","help"]."""
        def decorator(func):
            self._order += 1
            self._handlers.append(_Handler(func, filter, commands, int(priority), self._order))
            self._handlers.sort(key=lambda h: (h.priority, h.order))
            return func
        return decorator

    def on_callback_query(self, data=None, filter=None, priority=HandlerPriority.NORMAL):
        """دکوراتور هندلر دکمهٔ شیشه‌ای. data می‌تواند متن، لیست، یا پیشوند با * باشد."""
        def decorator(func):
            self._order += 1
            self._callback_handlers.append(
                _CallbackHandler(func, data, filter, int(priority), self._order)
            )
            self._callback_handlers.sort(key=lambda h: (h.priority, h.order))
            return func
        return decorator

    @staticmethod
    def _match_commands(text, commands):
        if not text or not commands:
            return False
        first = text.split(None, 1)[0]
        if not first.startswith("/"):
            return False
        name = first[1:].split("@", 1)[0].lower()
        cmds = [commands] if isinstance(commands, str) else commands
        return name in {c.lstrip("/").lower() for c in cmds}

    @staticmethod
    def _match_data(pattern, data):
        if pattern is None:
            return True
        if data is None:
            return False
        if callable(pattern):
            return bool(pattern(data))
        pats = [pattern] if isinstance(pattern, str) else list(pattern)
        for p in pats:
            if p.endswith("*"):
                if data.startswith(p[:-1]):
                    return True
            elif data == p:
                return True
        return False

    # ----------------------------------------------------------- پردازش آپدیت
    async def _run_handler(self, func, *args):
        try:
            result = func(*args)
            if inspect.isawaitable(result):
                await result
        except Exception as e:  # noqa: BLE001
            handled = False
            try:
                handled = await self.errors.handle(e, *args)
            except Exception:  # noqa: BLE001
                logger.exception("error handler failed")
            if not handled:
                logger.exception("Unhandled error in handler %s", getattr(func, "__name__", func))

    async def _dispatch_message(self, message):
        for h in self._handlers:
            if h.commands and not self._match_commands(message.text or message.caption, h.commands):
                continue
            if h.filter is not None and not h.filter(message):
                continue
            if h.commands:
                parts = (message.text or "").split(None, 1)
                message.command_args = parts[1] if len(parts) > 1 else ""
            await self._run_handler(h.func, message)
            return True
        return False

    async def _dispatch_callback(self, callback):
        for h in self._callback_handlers:
            if not self._match_data(h.data, callback.data):
                continue
            if h.filter is not None and not h.filter(callback):
                continue
            await self._run_handler(h.func, callback)
            return True
        return False

    async def process_update(self, raw_update):
        """یک آپدیت خام (dict) را پردازش می‌کند."""
        if not isinstance(raw_update, dict):
            return
        for key in ("message", "channel_post"):
            if isinstance(raw_update.get(key), dict):
                await self._dispatch_message(Message(raw_update[key], self))
                return
        if isinstance(raw_update.get("callback_query"), dict):
            await self._dispatch_callback(Callback(raw_update["callback_query"], self))

    # ------------------------------------------------------------- polling
    async def poll(self, interval=1.0, timeout=30, limit=100):
        """حلقهٔ long-polling با getUpdates."""
        self._running = True
        while self._running:
            try:
                updates = await self.get_updates(offset=self._offset, limit=limit, timeout=timeout)
            except FloodWait as e:
                await asyncio.sleep(e.retry_after or interval)
                continue
            except Unauthorized:
                self._running = False
                raise
            except asyncio.CancelledError:
                raise
            except (NetworkError, AttapyError) as e:
                logger.warning("polling error: %s", e)
                await asyncio.sleep(max(interval, 3))
                continue
            for upd in updates or []:
                try:
                    self._offset = int(upd["update_id"]) + 1
                except (KeyError, TypeError, ValueError):
                    pass
                try:
                    await self.process_update(upd)
                except Exception:  # noqa: BLE001
                    logger.exception("process_update failed")
            if not updates:
                await asyncio.sleep(interval)

    async def start_polling(self, interval=1.0, timeout=30):
        """polling را در پس‌زمینه شروع می‌کند و task را برمی‌گرداند."""
        await self.start()
        self._task = asyncio.create_task(self.poll(interval, timeout))
        return self._task

    def stop(self):
        """حلقهٔ polling را متوقف می‌کند."""
        self._running = False

    async def _main(self, interval, timeout):
        await self.start()
        try:
            await self.poll(interval, timeout)
        finally:
            await self.close()

    def run(self, interval=1.0, timeout=30):
        """نقطهٔ ورود ساده: ربات را تا Ctrl+C اجرا می‌کند."""
        try:
            asyncio.run(self._main(interval, timeout))
        except KeyboardInterrupt:
            logger.info("stopped")

    # ------------------------------------------------------------ Bot API
    async def get_me(self):
        return await self._request("getMe")

    async def get_updates(self, offset=None, limit=None, timeout=None, allowed_updates=None):
        http_timeout = (timeout or 0) + 15
        return await self._request(
            "getUpdates",
            {"offset": offset, "limit": limit, "timeout": timeout, "allowed_updates": allowed_updates},
            timeout=http_timeout,
        )

    async def get_webhook_info(self):
        return await self._request("getWebhookInfo")

    async def set_webhook(self, url, certificate=None, ip_address=None, max_connections=None,
                          allowed_updates=None, drop_pending_updates=None):
        return await self._request("setWebhook", {
            "url": url, "certificate": certificate, "ip_address": ip_address,
            "max_connections": max_connections, "allowed_updates": allowed_updates,
            "drop_pending_updates": drop_pending_updates,
        })

    async def delete_webhook(self, drop_pending_updates=None):
        return await self._request("deleteWebhook", {"drop_pending_updates": drop_pending_updates})

    async def log_out(self):
        return await self._request("logOut")

    async def send_message(self, chat_id, text, parse_mode=None, entities=None, reply_markup=None,
                           disable_web_page_preview=None, reply_to_message_id=None,
                           allow_sending_without_reply=None, **kwargs):
        return await self._request("sendMessage", {
            "chat_id": chat_id, "text": text, "parse_mode": self._pm(parse_mode),
            "entities": entities, "reply_markup": reply_markup,
            "disable_web_page_preview": disable_web_page_preview,
            "reply_to_message_id": reply_to_message_id,
            "allow_sending_without_reply": allow_sending_without_reply, **kwargs,
        })

    async def forward_message(self, chat_id, from_chat_id, message_id, **kwargs):
        return await self._request("forwardMessage", {
            "chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id, **kwargs})

    async def copy_message(self, chat_id, from_chat_id, message_id, caption=None, parse_mode=None,
                           caption_entities=None, reply_markup=None, **kwargs):
        return await self._request("copyMessage", {
            "chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id,
            "caption": caption, "parse_mode": self._pm(parse_mode),
            "caption_entities": caption_entities, "reply_markup": reply_markup, **kwargs})

    async def send_photo(self, chat_id, photo, caption=None, parse_mode=None,
                         caption_entities=None, reply_markup=None, **kwargs):
        return await self._send_media("sendPhoto", chat_id, "photo", photo, {
            "caption": caption, "parse_mode": self._pm(parse_mode),
            "caption_entities": caption_entities, "reply_markup": reply_markup}, **kwargs)

    async def send_audio(self, chat_id, audio, caption=None, parse_mode=None, duration=None,
                         performer=None, title=None, reply_markup=None, **kwargs):
        return await self._send_media("sendAudio", chat_id, "audio", audio, {
            "caption": caption, "parse_mode": self._pm(parse_mode), "duration": duration,
            "performer": performer, "title": title, "reply_markup": reply_markup}, **kwargs)

    async def send_document(self, chat_id, document, caption=None, parse_mode=None,
                            reply_markup=None, **kwargs):
        return await self._send_media("sendDocument", chat_id, "document", document, {
            "caption": caption, "parse_mode": self._pm(parse_mode),
            "reply_markup": reply_markup}, **kwargs)

    async def send_video(self, chat_id, video, caption=None, parse_mode=None, duration=None,
                         width=None, height=None, supports_streaming=None, reply_markup=None, **kwargs):
        return await self._send_media("sendVideo", chat_id, "video", video, {
            "caption": caption, "parse_mode": self._pm(parse_mode), "duration": duration,
            "width": width, "height": height, "supports_streaming": supports_streaming,
            "reply_markup": reply_markup}, **kwargs)

    async def send_animation(self, chat_id, animation, caption=None, parse_mode=None, duration=None,
                             width=None, height=None, reply_markup=None, **kwargs):
        return await self._send_media("sendAnimation", chat_id, "animation", animation, {
            "caption": caption, "parse_mode": self._pm(parse_mode), "duration": duration,
            "width": width, "height": height, "reply_markup": reply_markup}, **kwargs)

    async def send_voice(self, chat_id, voice, caption=None, parse_mode=None, duration=None,
                         reply_markup=None, **kwargs):
        return await self._send_media("sendVoice", chat_id, "voice", voice, {
            "caption": caption, "parse_mode": self._pm(parse_mode), "duration": duration,
            "reply_markup": reply_markup}, **kwargs)

    async def send_video_note(self, chat_id, video_note, duration=None, length=None,
                              reply_markup=None, **kwargs):
        return await self._send_media("sendVideoNote", chat_id, "video_note", video_note, {
            "duration": duration, "length": length, "reply_markup": reply_markup}, **kwargs)

    async def send_sticker(self, chat_id, sticker, reply_markup=None, **kwargs):
        return await self._send_media("sendSticker", chat_id, "sticker", sticker,
                                      {"reply_markup": reply_markup}, **kwargs)

    async def send_media_group(self, chat_id, media, **kwargs):
        """media: لیست دیکشنری‌های InputMedia (با file_id یا URL؛ آپلود فایل محلی پشتیبانی نمی‌شود)."""
        return await self._request("sendMediaGroup", {"chat_id": chat_id, "media": media, **kwargs})

    async def send_location(self, chat_id, latitude, longitude, horizontal_accuracy=None,
                            reply_markup=None, **kwargs):
        return await self._request("sendLocation", {
            "chat_id": chat_id, "latitude": latitude, "longitude": longitude,
            "horizontal_accuracy": horizontal_accuracy, "reply_markup": reply_markup, **kwargs})

    async def send_contact(self, chat_id, phone_number, first_name, last_name=None, vcard=None,
                           reply_markup=None, **kwargs):
        return await self._request("sendContact", {
            "chat_id": chat_id, "phone_number": phone_number, "first_name": first_name,
            "last_name": last_name, "vcard": vcard, "reply_markup": reply_markup, **kwargs})

    async def send_dice(self, chat_id, emoji=None, reply_markup=None, **kwargs):
        return await self._request("sendDice", {
            "chat_id": chat_id, "emoji": emoji, "reply_markup": reply_markup, **kwargs})

    async def send_chat_action(self, chat_id, action, **kwargs):
        return await self._request("sendChatAction", {"chat_id": chat_id, "action": action, **kwargs})

    async def edit_message_text(self, text, chat_id=None, message_id=None, inline_message_id=None,
                                parse_mode=None, entities=None, reply_markup=None,
                                disable_web_page_preview=None, **kwargs):
        return await self._request("editMessageText", {
            "text": text, "chat_id": chat_id, "message_id": message_id,
            "inline_message_id": inline_message_id, "parse_mode": self._pm(parse_mode),
            "entities": entities, "reply_markup": reply_markup,
            "disable_web_page_preview": disable_web_page_preview, **kwargs})

    async def edit_message_caption(self, chat_id=None, message_id=None, inline_message_id=None,
                                   caption=None, parse_mode=None, caption_entities=None,
                                   reply_markup=None, **kwargs):
        return await self._request("editMessageCaption", {
            "chat_id": chat_id, "message_id": message_id, "inline_message_id": inline_message_id,
            "caption": caption, "parse_mode": self._pm(parse_mode),
            "caption_entities": caption_entities, "reply_markup": reply_markup, **kwargs})

    async def edit_message_media(self, media, chat_id=None, message_id=None, inline_message_id=None,
                                 reply_markup=None, **kwargs):
        return await self._request("editMessageMedia", {
            "media": media, "chat_id": chat_id, "message_id": message_id,
            "inline_message_id": inline_message_id, "reply_markup": reply_markup, **kwargs})

    async def edit_message_reply_markup(self, chat_id=None, message_id=None, inline_message_id=None,
                                        reply_markup=None, **kwargs):
        return await self._request("editMessageReplyMarkup", {
            "chat_id": chat_id, "message_id": message_id, "inline_message_id": inline_message_id,
            "reply_markup": reply_markup, **kwargs})

    async def delete_message(self, chat_id, message_id):
        return await self._request("deleteMessage", {"chat_id": chat_id, "message_id": message_id})

    async def answer_callback_query(self, callback_query_id, text=None, show_alert=False, url=None,
                                    cache_time=None, **kwargs):
        return await self._request("answerCallbackQuery", {
            "callback_query_id": callback_query_id, "text": text,
            "show_alert": show_alert or None, "url": url, "cache_time": cache_time, **kwargs})

    async def pin_chat_message(self, chat_id, message_id, **kwargs):
        return await self._request("pinChatMessage", {
            "chat_id": chat_id, "message_id": message_id, **kwargs})

    async def unpin_chat_message(self, chat_id, message_id=None, **kwargs):
        return await self._request("unpinChatMessage", {
            "chat_id": chat_id, "message_id": message_id, **kwargs})

    async def get_chat(self, chat_id):
        return await self._request("getChat", {"chat_id": chat_id})

    async def get_user_profile_photos(self, user_id, offset=None, limit=None):
        return await self._request("getUserProfilePhotos", {
            "user_id": user_id, "offset": offset, "limit": limit})

    async def get_sticker_set(self, name):
        return await self._request("getStickerSet", {"name": name})

    async def get_file(self, file_id):
        return await self._request("getFile", {"file_id": file_id})

    async def download_file(self, file_path, destination):
        """فایل را با file_path (یا خروجی get_file) دانلود و در destination ذخیره می‌کند."""
        if isinstance(file_path, dict):
            file_path = file_path.get("file_path")
        if not file_path:
            raise ValidationError("file_path is required")
        status, raw = await asyncio.to_thread(http_get, self.file_url(file_path), self.timeout)
        if status != 200:
            raise SoroushPlusAPIError("downloadFile", f"HTTP {status}", status)
        with open(destination, "wb") as f:
            f.write(raw)
        return destination

    async def set_my_commands(self, commands, scope=None, language_code=None):
        items = []
        for c in commands:
            if isinstance(c, dict):
                items.append(c)
            else:
                items.append({"command": c[0], "description": c[1]})
        return await self._request("setMyCommands", {
            "commands": items, "scope": scope, "language_code": language_code})

    async def get_my_commands(self, scope=None, language_code=None):
        return await self._request("getMyCommands", {"scope": scope, "language_code": language_code})

    async def delete_my_commands(self, scope=None, language_code=None):
        return await self._request("deleteMyCommands", {"scope": scope, "language_code": language_code})
