"""اولویت هندلرها و مدیریت خطا."""
import enum
import inspect


class HandlerPriority(enum.IntEnum):
    HIGHEST = 0
    HIGH = 25
    NORMAL = 50
    LOW = 75
    LOWEST = 100


class ErrorHandlerBuilder:
    """ثبت هندلر برای خطاهایی که داخل هندلرهای پیام رخ می‌دهد."""

    def __init__(self):
        self._handlers = []

    def add(self, func, *exceptions):
        """ثبت مستقیم یک تابع (بدون دکوراتور)."""
        self._handlers.append((func, tuple(exceptions)))
        return func

    def catch(self, *exceptions):
        """دکوراتور: @robot.errors.catch(ValueError)"""
        def decorator(func):
            return self.add(func, *exceptions)
        return decorator

    async def handle(self, error, *args, **kwargs):
        """اولین هندلر منطبق را اجرا می‌کند. اگر هندلری بود True برمی‌گرداند."""
        for func, excs in self._handlers:
            if not excs or isinstance(error, excs):
                result = func(error, *args, **kwargs)
                if inspect.isawaitable(result):
                    await result
                return True
        return False
