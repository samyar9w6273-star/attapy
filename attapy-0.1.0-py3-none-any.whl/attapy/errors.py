"""استثناهای attapy."""


class AttapyError(Exception):
    """کلاس پایهٔ همهٔ خطاهای کتابخونه."""


# نام قدیمی (سازگاری با aiosroosh)
PysrooshError = AttapyError


class NetworkError(AttapyError):
    """خطای اتصال به سرور (اینترنت، DNS، timeout یا آدرس base_url اشتباه)."""


class ValidationError(AttapyError):
    """ورودی نامعتبر به یکی از متدها."""


class SessionError(AttapyError):
    """خطای مربوط به نشست."""


class SessionExpiredError(SessionError):
    """نشست منقضی شده است."""


class UnsupportedByBackendError(AttapyError):
    """این قابلیت توسط سرور پشتیبانی نمی‌شود."""


class SoroushPlusAPIError(AttapyError):
    """خطای برگشتی از Bot API سروش‌پلاس."""

    def __init__(self, method="", description="", error_code=None, parameters=None):
        self.method = method
        self.description = description
        self.error_code = error_code
        self.parameters = parameters or {}
        super().__init__(f"[{method}] {error_code}: {description}")


class RPCError(SoroushPlusAPIError):
    pass


class BadRequest(RPCError):
    pass


class AuthError(RPCError):
    pass


class Unauthorized(AuthError):
    pass


class ChatNotFound(BadRequest):
    pass


class MessageNotFound(BadRequest):
    pass


class UserNotFound(BadRequest):
    pass


class FloodWait(RPCError):
    @property
    def retry_after(self):
        try:
            return int(self.parameters.get("retry_after", 0))
        except (TypeError, ValueError):
            return 0


def raise_for_error(method, data, status_code=None):
    """از روی پاسخ ناموفق سرور، استثنای مناسب را بالا می‌اندازد."""
    if not isinstance(data, dict):
        data = {}
    code = data.get("error_code") or status_code
    desc = str(data.get("description") or data.get("message") or "Unknown error")
    params = data.get("parameters") or {}
    low = desc.lower()
    args = (method, desc, code, params)

    if code == 429 or "too many requests" in low or "flood" in low:
        raise FloodWait(*args)
    if code in (401, 403) and ("unauthorized" in low or "token" in low or code == 401):
        raise Unauthorized(*args)
    if code == 401:
        raise Unauthorized(*args)
    if "chat not found" in low:
        raise ChatNotFound(*args)
    if "message" in low and "not found" in low:
        raise MessageNotFound(*args)
    if "user not found" in low:
        raise UserNotFound(*args)
    if code == 400:
        raise BadRequest(*args)
    if code in (401, 403):
        raise AuthError(*args)
    raise SoroushPlusAPIError(*args)
