"""تست‌ها با یک سرور Bot API جعلی محلی (بدون اینترنت)."""
import asyncio
import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import attapy
from attapy import Button, HandlerPriority, Robot, filters
from attapy.errors import (BadRequest, ChatNotFound, FloodWait, MessageNotFound, Unauthorized)

LOG = []          # درخواست‌های دریافتی سرور
QUEUE = []        # آپدیت‌های آمادهٔ تحویل


class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj, status=200, raw=None):
        body = raw if raw is not None else json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/file/bottok/"):
            return self._send(None, raw=b"FILEDATA")
        self._send({"ok": False}, 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n)
        ctype = self.headers.get("Content-Type", "")
        method = self.path.split("/")[-1]
        if not self.path.startswith("/bottok/"):
            return self._send({"ok": False, "error_code": 401, "description": "Unauthorized"}, 401)
        data = json.loads(body) if ctype.startswith("application/json") and body else {}
        LOG.append((method, data, ctype, body))
        if method == "getMe":
            return self._send({"ok": True, "result": {"id": 1, "is_bot": True, "first_name": "T", "username": "tbot"}})
        if method == "getUpdates":
            ups = list(QUEUE)
            QUEUE.clear()
            return self._send({"ok": True, "result": ups})
        if method == "sendMessage":
            if data.get("chat_id") == 404:
                return self._send({"ok": False, "error_code": 400, "description": "Bad Request: chat not found"}, 400)
            if data.get("chat_id") == 429:
                return self._send({"ok": False, "error_code": 429, "description": "Too Many Requests",
                                   "parameters": {"retry_after": 7}}, 429)
            return self._send({"ok": True, "result": {"message_id": 99, "chat": {"id": data["chat_id"], "type": "private"}, "text": data["text"]}})
        if method == "deleteMessage":
            return self._send({"ok": False, "error_code": 400, "description": "Bad Request: message to delete not found"}, 400)
        self._send({"ok": True, "result": True})


def start_server():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Fake)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_port}"


async def main():
    srv, url = start_server()
    bot = Robot("tok", base_url=url, parse_mode="HTML")

    # ---- API پایه
    me = await bot.get_me()
    assert me["username"] == "tbot"
    r = await bot.send_message(5, "hi", reply_markup=Button.builder(inline=True).add(Button.inline("A", "a")).build())
    assert r["message_id"] == 99
    m, d, *_ = [x for x in LOG if x[0] == "sendMessage"][-1]
    assert d["parse_mode"] == "HTML" and d["reply_markup"]["inline_keyboard"][0][0]["callback_data"] == "a"
    assert "reply_to_message_id" not in d          # None ها حذف می‌شوند

    # ---- خطاها
    for cid, exc in ((404, ChatNotFound), (429, FloodWait)):
        try:
            await bot.send_message(cid, "x")
            raise SystemExit(f"expected {exc}")
        except exc as e:
            if exc is FloodWait:
                assert e.retry_after == 7
    try:
        await bot.delete_message(1, 2)
        raise SystemExit("expected MessageNotFound")
    except MessageNotFound:
        pass
    try:
        await Robot("bad", base_url=url).get_me()
        raise SystemExit("expected Unauthorized")
    except Unauthorized:
        pass

    # ---- آپلود فایل و دانلود
    await bot.send_photo(1, b"\x89PNGDATA", caption="c")
    _, _, ctype, body = [x for x in LOG if x[0] == "sendPhoto"][-1]
    assert ctype.startswith("multipart/form-data") and b'name="photo"' in body and b"PNGDATA" in body
    out = await bot.download_file("a/b.txt", "/tmp/_attapy_dl.txt")
    assert open(out, "rb").read() == b"FILEDATA"

    # ---- فیلترها
    class M:  # پیام ساختگی
        pass
    msg = attapy.Message({"message_id": 1, "text": "/start  arg1 arg2", "chat": {"id": 5, "type": "private"},
                          "from": {"id": 7, "first_name": "Ali", "last_name": "R"}}, bot)
    assert filters.command("start")(msg) and not filters.command("help")(msg)
    assert (filters.private & filters.user(7))(msg) and not (filters.group | filters.user(8))(msg)
    assert (~filters.group)(msg) and filters.regex(r"arg(\d)")(msg) and msg.match.group(1) == "1"
    assert msg.from_user.full_name == "Ali R" and msg.chat.is_private

    # ---- هندلرها، اولویت، command_args، خطا
    calls = []

    @bot.on_message(commands=["start"], priority=HandlerPriority.LOW)
    async def low(m):
        calls.append("low")

    @bot.on_message(commands=["start"])
    async def normal(m):
        calls.append(("normal", m.command_args))
        await m.reply("pong")

    @bot.on_message(filter=filters.regex("boom"))
    async def boom(m):
        raise ValueError("bad")

    errs = []

    @bot.errors.catch(ValueError)
    async def on_err(e, m):
        errs.append(str(e))

    @bot.on_callback_query(data="btn:*")
    async def cb(c):
        calls.append(("cb", c.data))
        await c.answer("ok", show_alert=True)

    QUEUE.extend([
        {"update_id": 10, "message": {"message_id": 1, "text": "/start xyz", "chat": {"id": 5, "type": "private"}, "from": {"id": 7, "first_name": "A"}}},
        {"update_id": 11, "message": {"message_id": 2, "text": "boom", "chat": {"id": 5, "type": "private"}}},
        {"update_id": 12, "callback_query": {"id": "cq1", "data": "btn:7", "from": {"id": 7, "first_name": "A"}, "message": {"message_id": 1, "chat": {"id": 5, "type": "private"}}}},
    ])
    task = await bot.start_polling(interval=0.1, timeout=1)
    for _ in range(50):
        await asyncio.sleep(0.1)
        if len(calls) >= 2 and errs:
            break
    bot.stop()
    await bot.close()
    assert calls == [("normal", "xyz"), ("cb", "btn:7")], calls
    assert errs == ["bad"], errs
    assert bot._offset == 13
    ans = [x for x in LOG if x[0] == "answerCallbackQuery"][-1][1]
    assert ans["callback_query_id"] == "cq1" and ans["show_alert"] is True
    replies = [x[1] for x in LOG if x[0] == "sendMessage" and x[1].get("text") == "pong"]
    assert replies and replies[0]["reply_to_message_id"] == 1

    # ---- ساخت صفحه‌کلید
    kb = Button.keyboard_markup([[Button.keyboard("a")], Button.row(Button.keyboard("b"), Button.keyboard("c", request_contact=True))])
    assert len(kb["keyboard"]) == 2 and kb["keyboard"][1][1]["request_contact"] is True
    assert Button.remove_keyboard() == {"remove_keyboard": True}
    assert Button.force_reply()["force_reply"] is True
    b = Button.builder().add(text="x").new_row().add(text="y").build()
    assert [len(r) for r in b["keyboard"]] == [1, 1]

    srv.shutdown()
    print("ALL TESTS PASSED")


asyncio.run(main())
